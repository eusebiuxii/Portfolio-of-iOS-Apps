//
//  ViewController.swift
//  Research Papers
//
//  Created by Moldovan, Eusebiu on 09/12/2022.
//

import UIKit

class ViewController: UIViewController {

    var content:techReport? = nil
    
    @IBOutlet weak var label: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        label.text = """
            Title: \(content?.title ?? "unavailable")
            Year: \(content?.year ?? "unavailable")
            Authors: \(content?.authors ?? "unavailable")
            Email: \(content?.email ?? "unavailable")
            -----------------
            Abstract: \(content?.abstract ?? "unavailable")
            URL: \(String(describing: content?.pdf))
            """
        label.sizeToFit()
        
        
        
    }


}

