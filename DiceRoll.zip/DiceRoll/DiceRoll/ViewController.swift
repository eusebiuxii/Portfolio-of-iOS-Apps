//
//  ViewController.swift
//  DiceRoll
//
//  Created by Moldovan, Eusebiu on 15/12/2022.
//

import UIKit

class ViewController: UIViewController {

    

    @IBOutlet weak var field: UITextField!
    @IBOutlet weak var label: UILabel!
    
    @IBAction func button(_ sender: Any) {
        
        if field.text == ""{
            
        }else if field.text == String(product){
            label.text = "Correct!!! You guessed the correct number!"
        } else {
            label.text = "Your guess was wrong. The number was \(product)"
        }
        
        field.text = ""
        
        
    }

    var product = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let diceRoll1 = Int.random(in: 1..<7) //value between 1 and 6
        let diceRoll2 = Int.random(in: 1..<7) //value between 1 and 6
        product = diceRoll1 + diceRoll2
    }


}

